#!/usr/bin/env python
from setuptools import setup

NAME = 'Pillow'
PILLOW_VERSION = '3.4.2'

setup(
    name=NAME,
    version=PILLOW_VERSION,
    description='Python Imaging Library (Fork)',
    author='Alex Clark (Fork Author)',
    author_email='aclark@aclark.net',
    url='https://python-pillow.org',
    package_data={'PIL': ['*.so']},
    include_package_data=True,
    packages=['PIL'],
    license='Standard PIL License')
